

document.write(' \
<style type="text/css" media="screen">\
	 .dsq-widget ul.dsq-widget-list {\
	 padding: 0;\
	 margin: 0;\
	 text-align: left;\
	 }\
	 img.dsq-widget-avatar {\
	 width: 32px;\
	 height: 32px;\
	 border: 0px;\
	 margin: 0px;\
	 padding: 0px 3px 3px 0px;\
	 float: left;\
	 }\
	 a.dsq-widget-user {\
	 font-weight: bold;\
	 }\
	 a.dsq-widget-thread {\
	 font-weight: bold;\
	 }\
	 p.dsq-widget-meta {\
	 clear: both;\
	 font-size: 80%;\
	 padding: 0;\
	 margin: 0;\
	 }\
	 li.dsq-widget-item {\
	 margin: 15px 0;\
	 list-style-type: none;\
	 clear: both;\
	 }\
	 span.dsq-widget-clout {\
	 padding: 0 2px;\
	 background-color: #ff7300;\
	 color: #fff;\
	 }\
	 table.dsq-widget-horiz td {\
	 padding-right: 15px;\
	 }\
	 .dsq-widget-comment p {\
	 display: inline;\
	 }\
	 </style>\
	 <ul class="dsq-widget-list">\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/disqus_H1TrXE2WEq/">Dheeraj</a>\
	 <span class="dsq-widget-comment"><p>Simple solution can be start from the end and...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-245-for-2-5-years/">Amazon Interview Experience | Set 245 (For 2.5 Years Experienced)</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-245-for-2-5-years/#comment-2514305750">1 minute ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/surbhijain93/">surbhijain93</a>\
	 <span class="dsq-widget-comment"><p>Can u pls tell what did u answer for round 5...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-244-for-sde-1-hyderabad/">Amazon Interview Experience | Set 244 (For SDE-1)</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-244-for-sde-1-hyderabad/#comment-2514298944">11 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/disqus_jDv1RM2SIX/">Syed Nasir</a>\
	 <span class="dsq-widget-comment"><p>The easiest way of Passing 2d array is:...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/pass-2d-array-parameter-c/">How to pass a 2D array as a parameter in C?</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/pass-2d-array-parameter-c/#comment-2514264439">1 hour ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/anandnahar/">Anand Nahar</a>\
	 <span class="dsq-widget-comment"><p>This is what I think, may be wrong!! The tree...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/how-to-determine-if-a-binary-tree-is-balanced/">How to determine if a binary tree is height-balanced?</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/how-to-determine-if-a-binary-tree-is-balanced/#comment-2514238698">1 hour ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/SaranshSharma1/">Saransh Sharma</a>\
	 <span class="dsq-widget-comment"><p>I am currently working for Polaris Networks,...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-244-for-sde-1-hyderabad/">Amazon Interview Experience | Set 244 (For SDE-1)</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-244-for-sde-1-hyderabad/#comment-2514220263">1 hour ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/SaranshSharma1/">Saransh Sharma</a>\
	 <span class="dsq-widget-comment"><p>It was actually network packet class designing....</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-244-for-sde-1-hyderabad/">Amazon Interview Experience | Set 244 (For SDE-1)</a>&nbsp;&middot;&nbsp;<a href="http://www.geeksforgeeks.org/amazon-interview-experience-set-244-for-sde-1-hyderabad/#comment-2514220221">1 hour ago</a></p>\
	 </li>\
	 </ul>\
');
