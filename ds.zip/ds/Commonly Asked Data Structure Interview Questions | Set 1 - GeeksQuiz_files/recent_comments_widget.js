

document.write(' \
<style type="text/css" media="screen">\
	 .dsq-widget ul.dsq-widget-list {\
	 padding: 0;\
	 margin: 0;\
	 text-align: left;\
	 }\
	 img.dsq-widget-avatar {\
	 width: 32px;\
	 height: 32px;\
	 border: 0px;\
	 margin: 0px;\
	 padding: 0px 3px 3px 0px;\
	 float: left;\
	 }\
	 a.dsq-widget-user {\
	 font-weight: bold;\
	 }\
	 a.dsq-widget-thread {\
	 font-weight: bold;\
	 }\
	 p.dsq-widget-meta {\
	 clear: both;\
	 font-size: 80%;\
	 padding: 0;\
	 margin: 0;\
	 }\
	 li.dsq-widget-item {\
	 margin: 15px 0;\
	 list-style-type: none;\
	 clear: both;\
	 }\
	 span.dsq-widget-clout {\
	 padding: 0 2px;\
	 background-color: #ff7300;\
	 color: #fff;\
	 }\
	 table.dsq-widget-horiz td {\
	 padding-right: 15px;\
	 }\
	 .dsq-widget-comment p {\
	 display: inline;\
	 }\
	 </style>\
	 <ul class="dsq-widget-list">\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/gatecse2/">Mithlesh Upadhyay</a>\
	 <span class="dsq-widget-comment"><p>No, it\'s option (a). Click "RUN" <a href="http://cpp.sh/7zgp" rel="nofollow">cpp.sh/7zgp</a></p></span>\
	 <p class="dsq-widget-meta"><a href="http://geeksquiz.com/gate-cs-2016-set-1/">GATE-CS-2016 (Set 1)</a>&nbsp;&middot;&nbsp;<a href="http://geeksquiz.com/gate-cs-2016-set-1/#comment-2514311139">0 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/disqus_aPOpzEbFrt/">Manoj</a>\
	 <span class="dsq-widget-comment"><p>I believe C-Look algorithm will not consider...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://geeksquiz.com/gate-gate-cs-2016-set-1-question-58/">GATE | GATE-CS-2016 (Set 1) | Question 58</a>&nbsp;&middot;&nbsp;<a href="http://geeksquiz.com/gate-gate-cs-2016-set-1-question-58/#comment-2514311042">0 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/gauravkumarrajora/">Gaurav Kumar Rajora</a>\
	 <span class="dsq-widget-comment"><p>do we have to consider long jump or not?</p></span>\
	 <p class="dsq-widget-meta"><a href="http://geeksquiz.com/gate-gate-cs-2016-set-1-question-58/">GATE | GATE-CS-2016 (Set 1) | Question 58</a>&nbsp;&middot;&nbsp;<a href="http://geeksquiz.com/gate-gate-cs-2016-set-1-question-58/#comment-2514305147">9 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/satyanarayanabolenedi/">Satyanarayana Bolenedi</a>\
	 <span class="dsq-widget-comment"><p>nice!!</p></span>\
	 <p class="dsq-widget-meta"><a href="http://geeksquiz.com/default-arguments-c/">Default Arguments in C++</a>&nbsp;&middot;&nbsp;<a href="http://geeksquiz.com/default-arguments-c/#comment-2514177658">2 hours ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 bishnu\
	 <span class="dsq-widget-comment"><p>Opt .C</p></span>\
	 <p class="dsq-widget-meta"><a href="http://geeksquiz.com/gate-cs-2016-set-1/">GATE-CS-2016 (Set 1)</a>&nbsp;&middot;&nbsp;<a href="http://geeksquiz.com/gate-cs-2016-set-1/#comment-2514170882">3 hours ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="https://disqus.com/by/anandkrishnar/">Anandkrishna R</a>\
	 <span class="dsq-widget-comment"><p>13</p></span>\
	 <p class="dsq-widget-meta"><a href="http://geeksquiz.com/gate-gate-cs-2016-set-1-question-63/">GATE | GATE-CS-2016 (Set 1) | Question 63</a>&nbsp;&middot;&nbsp;<a href="http://geeksquiz.com/gate-gate-cs-2016-set-1-question-63/#comment-2514139487">3 hours ago</a></p>\
	 </li>\
	 </ul>\
');
